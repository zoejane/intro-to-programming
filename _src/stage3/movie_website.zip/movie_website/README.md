## Welcome to Zoe Jane's Movie Website  
- You can download **[movie_website.zip](https://github.com/zoejane/intro-to-programming/raw/master/_src/stage3/movie_website.zip)**, and unzip it.  
- Use [Python2](https://www.python.org/downloads/) to run **entertaiment_center.py**.  
- Enjoy it!

Zoe Jane  

